<?php include('header.php'); ?>

<div class="page-header">
<h1>Buy a lottery!</h1>
<p class="lead">People are winning fabulous prizes every day. You could win up to $5000000!</p>
<a href="buy.php" class="btn btn-lg btn-success">Play to win!</a>
</div>



<h1>Rules</h1>
<ul>
	<li>Each starter has $20</li>
	<li>Pay $2, and select 7 numbers. Comparing with the winning number:</li>
	<li>2 same numbers: you win $5</li>
	<li>3 same numbers: you win $20</li>
	<li>4 same numbers: you win $300</li>
	<li>5 same numbers: you win $1800</li>
	<li>6 same numbers: you win $200000</li>
	<li>7 same numbers: you win $5000000</li>

</ul>


<?php include('footer.php'); ?>