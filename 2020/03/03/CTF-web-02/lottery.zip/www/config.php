<?php
session_start();
$flag = 'this is not the real flag';
$flag_price = 9990000;
